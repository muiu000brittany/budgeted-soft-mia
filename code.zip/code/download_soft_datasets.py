from datasets import load_dataset
from pathlib import Path

out_root = Path("hf_datasets")
out_root.mkdir(parents=True, exist_ok=True)

print("=" * 100)
print("Downloading raw MIMIR arxiv dataset...")
print("=" * 100)

raw = load_dataset(
    "iamgroot42/mimir",
    name="arxiv",
    split="ngram_13_0.8",
    trust_remote_code=True,
)

print("raw dataset:", raw)
print("raw columns:", raw.column_names)
print("raw first sample:")
print(raw[0])

raw_out = out_root / "mimir_arxiv_ngram_13_0.8"
raw.save_to_disk(str(raw_out))
print("saved raw dataset to:", raw_out)

print("=" * 100)
print("Downloading paraphrased / obfuscated dataset...")
print("=" * 100)

para = load_dataset(
    "LLM-MIA/editing-syn-pr0.5-mimir-arxiv-ngram_13_0.8",
    split="train",
    trust_remote_code=True,
)

print("para dataset:", para)
print("para columns:", para.column_names)
print("para first sample:")
print(para[0])

para_out = out_root / "editing_syn_pr05_mimir_arxiv_ngram_13_0.8"
para.save_to_disk(str(para_out))
print("saved paraphrased dataset to:", para_out)

print("=" * 100)
print("Done.")
print("=" * 100)