import requests
from huggingface_hub import HfFolder

token = HfFolder.get_token()
print("token loaded:", token is not None)

proxies = {
    "http": "http://127.0.0.1:7897",
    "https": "http://127.0.0.1:7897",
}

headers = {}
if token:
    headers["Authorization"] = f"Bearer {token}"

url = "https://huggingface.co/api/whoami-v2"

r = requests.get(
    url,
    headers=headers,
    proxies=proxies,
    timeout=30,
)

print("status:", r.status_code)
print(r.text[:1000])